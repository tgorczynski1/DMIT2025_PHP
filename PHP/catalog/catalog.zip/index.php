<?php 

include("includes/header.php");

?>

<div class="jumbotron clearfix">
  <h1>Catalog of Cats</h1>
</div>
<div class="row">
<div class="col-md-5" >
<h2>Project Summary</h2>
<p>This is my final project in my DMIT 2025 (php) class. It's meant to be a show-off peice of eveything that has been learnt.</p>
<p>This is my last project for the program actually, as i'm graduating this semester. </p>
<p>I picked cats because they are cute to look at and make me smile.</p>

</div>
<div class="col-md-5" style="text-align:right;" >
<h2>Features</h2>
<p>This site demonstrates...</p>
<ul>
	<li>Bootstrap layouts</li>
	<li>Forms with PHP (CRUD)</li>
	<li>Image Uploading</li>
	<li>MySQL</li>
	<li>Javascript</li>
	<li>Filtering of DB Contents</li>
	<li>and more...</li>
</ul>
</div>
</div>
<?php

include("includes/footer.php");
?>