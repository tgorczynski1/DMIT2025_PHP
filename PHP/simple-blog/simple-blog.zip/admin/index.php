<?php 
	header("Location:login.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Simple Blog | Admin</title>
</head>
<body>
	
	<!-- I DON'T GOTTA DO NOTHIN' HERE! -->

</body>
</html>